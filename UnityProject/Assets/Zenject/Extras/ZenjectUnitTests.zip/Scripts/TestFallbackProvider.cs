using System;
using System.Collections.Generic;
using ModestTree.Zenject;
using NUnit.Framework;
using TestAssert=NUnit.Framework.Assert;
using System.Linq;

namespace ModestTree.Zenject.Test
{
    [TestFixture]
    public class TestFallbackProvider : TestWithContainer
    {
        public interface IFoo
        {
            int GetBar();
        }

        [Test]
        public void TestCase1()
        {
            _container.FallbackProvider = new TransientMockProvider(_container);

            var foo = _container.Resolve<IFoo>();

            TestAssert.AreEqual(foo.GetBar(), 0);
        }
    }
}
